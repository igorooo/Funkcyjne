trait Game {

  def rules() : String
  def NAME : String

}
