public enum Mode {
    NORMAL,IMPORTANT;

}
