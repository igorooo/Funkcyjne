public class ModeException extends Exception {

    public ModeException(){}

    public ModeException(String message){
        super(message);
    }
}
