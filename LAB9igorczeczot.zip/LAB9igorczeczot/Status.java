public enum Status {
    InProgress, Finished, Preparing
}
